class Attack
{
    public string Name;
    public int DamageAmount;

    public Attack(string name, int damageAmount)
    {
        Name = name;
        DamageAmount = damageAmount;
    }
}